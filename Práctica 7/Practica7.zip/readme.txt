Para ejecutar este programa se tiene que tener instalado el gnuplot
Y tiene que estar configurado para que se puede ejecutar desde el directorio en el que se ejecuta el programa
En caso contrario se pueden ver los datos en dataMe.txt que es generado luego de ejecutar el codigo
